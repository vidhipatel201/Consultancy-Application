# Consultancy-Application

This System is a web application for TAKE OFF Consultancy. Now a days in consultancy all the work  is done manually (i.e. Paper Based), this requires more efforts. With our reliable system, admin can enter the data of students who come for enquiry. Also the admin can get details of enquired Students anytime he/she wants. Student who wants to join the consultancy can get registered with our system for consultancy. Admin can track the registered student. Our System at consultancy keeps a record of present and past student with all the required details. This also keeps the record of visa status related to approval or rejection. Thus, by this system they can now easily find the  list of student which are relevant to queries, resulting into less delay in work , and providing uninterrupted , error free Part list.
           
Consultancy Application will replace their traditional paperwork and replace it with digitalization. 
